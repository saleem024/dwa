package dwa;

/**
 * Configuration staff
 */
public class Configuration {
    public static final String DRIVER_CLASS = "org.sqlite.JDBC";
    public static final String URL = "jdbc:sqlite:dwa.db";
//  public static final String USER = "admin";
//  public static final String PASSWORD = "password";
}
